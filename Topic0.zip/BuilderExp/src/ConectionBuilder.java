
public interface ConectionBuilder {
	public void buildUrl();

	public void buildUsr();

	public void buildPas();

	public Conection getConection();
}
