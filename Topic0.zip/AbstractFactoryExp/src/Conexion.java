
public interface Conexion {
	public void connect();
}
