public class Main {

	public static void main(String[] args) {
		  DatabaseType databaseType = DatabaseType.MYSQL; //creamos una DataBase Mysql
		    ConexionFactory connectionFactory= getConnectionFactory(databaseType);

		    AppEj application = new AppEj(connectionFactory);
		    application.start();
		  }

		  private static ConexionFactory getConnectionFactory(
		      DatabaseType databaseType)
		  {
		    switch (databaseType) //Evaluamos la base de datos ,en este caso es una MYSQL
		    {
		    case MYSQL:
		      return new MsqlConexionFactory();
		    default:
		      return new PostgreSqlConexionFactory();
		    }
		  }

		  private enum DatabaseType
		  {
		    MYSQL, POSTGRE;
		  }

}
