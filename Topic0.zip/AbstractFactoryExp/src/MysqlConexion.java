

public class MysqlConexion implements Conexion {
	  @Override
	  public void connect()
	  {
	    System.out.println("Connectando a MSQL...");
	  }
}
