
public class MsqlConexionFactory implements ConexionFactory {
	 @Override
	  public Conexion getConnection() {
	    return new MysqlConexion();
	  }
}
