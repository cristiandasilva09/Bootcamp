
public interface ConexionFactory {
	Conexion getConnection();
}
