
public class PostgreSqlConexionFactory implements ConexionFactory {

	  @Override
	  public Conexion getConnection() {
	    return new PostgreSqlConexion();
	  }
}