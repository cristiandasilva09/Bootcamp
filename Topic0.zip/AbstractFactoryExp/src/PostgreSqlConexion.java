
public class PostgreSqlConexion implements Conexion{

	@Override
	public void connect()
	{
		System.out.println("Connectando a PostgreSQL...");
    }

}
