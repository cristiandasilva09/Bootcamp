
public class AppEj {
	private final ConexionFactory conexionFactory;

	  public AppEj(ConexionFactory connectionFactory) {
	    this.conexionFactory = connectionFactory;
	  }

	 public void start() {
	    Conexion connection = conexionFactory.getConnection();
	    connection.connect();
	    
	  }
}
