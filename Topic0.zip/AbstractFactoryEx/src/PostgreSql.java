
public class PostgreSql implements BD {
	@Override
	public void conectar() {
		System.out.println("BD PostgreSql::conectar() method.");
	}
}
