
public interface BD {
void conectar();

}
