
public abstract class AbstractFactory {
abstract BD getBD(String bd);
abstract Query getQuery(String query);
}
