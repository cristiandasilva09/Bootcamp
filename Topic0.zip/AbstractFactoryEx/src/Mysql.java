
public class Mysql implements BD {
@Override
public void conectar() {
	System.out.println("BD MSyql::conectar() method.");
}
}
