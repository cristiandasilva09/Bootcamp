
public class Delete  implements Query{
@Override public void consulta() {
	System.out.println("Delete from personas where (id= ?)::consulta method. ");
}

}
