
public interface Query {
 void consulta();
}
