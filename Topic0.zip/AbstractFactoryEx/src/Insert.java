
public class Insert implements Query {
@Override
public void consulta() {
	System.out.println("Inster into personas values(?,?,?)::consulta method.");
}
}
